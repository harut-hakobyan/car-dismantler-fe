import { Paper, Stack, TextField } from '@mui/material';
import PageHeader from '../../components/PageHeader';
import { useAuth } from '../../hooks/useAuth';

export default function ProfilePage() {
    const { user } = useAuth();

    return (
        <>
            <PageHeader
                title="Profile"
                description="Your signed-in account details."
            />

            <Paper sx={{ p: 3, borderRadius: 2, maxWidth: 640 }}>
                <Stack spacing={2}>
                    <TextField label="Name" value={user?.name ?? ''} />
                    <TextField label="Email" value={user?.email ?? ''} />
                    <TextField label="Role" value="Administrator" />
                </Stack>
            </Paper>
        </>
    );
}
