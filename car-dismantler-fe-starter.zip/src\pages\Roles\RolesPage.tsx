import CrudPage, { type Column } from '../../components/CrudPage';
import { roles } from '../../api/mockData';
import type { RoleResource } from '../../types/resources';

const columns: Column<RoleResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'name', label: 'Role' },
    { key: 'permissions', label: 'Permissions' },
    { key: 'users', label: 'Users', type: 'number' },
    { key: 'status', label: 'Status', type: 'status' },
];

export default function RolesPage() {
    return (
        <CrudPage
            title="Roles"
            description="Define permission groups for admin users."
            actionLabel="Add role"
            initialRows={roles}
            columns={columns}
        />
    );
}
