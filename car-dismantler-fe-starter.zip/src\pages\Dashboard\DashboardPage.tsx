import {
    Box,
    Grid,
    Paper,
    Stack,
    Typography,
} from '@mui/material';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import PeopleIcon from '@mui/icons-material/People';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import PageHeader from '../../components/PageHeader';
import { cars, customers, orders, parts } from '../../api/mockData';

const stats = [
    {
        label: 'Cars',
        value: cars.length,
        icon: <DirectionsCarIcon />,
    },
    {
        label: 'Parts',
        value: parts.length,
        icon: <Inventory2Icon />,
    },
    {
        label: 'Orders',
        value: orders.length,
        icon: <ShoppingCartIcon />,
    },
    {
        label: 'Customers',
        value: customers.length,
        icon: <PeopleIcon />,
    },
];

export default function DashboardPage() {
    return (
        <>
            <PageHeader
                title="Dashboard"
                description="Operational overview for dismantling, inventory, and sales."
            />

            <Grid container spacing={2}>
                {stats.map((stat) => (
                    <Grid key={stat.label} size={{ xs: 12, sm: 6, lg: 3 }}>
                        <Paper sx={{ p: 3, borderRadius: 2 }}>
                            <Stack
                                direction="row"
                                spacing={2}
                                sx={{ alignItems: 'center' }}
                            >
                                <Box
                                    sx={{
                                        display: 'grid',
                                        placeItems: 'center',
                                        width: 44,
                                        height: 44,
                                        borderRadius: 2,
                                        bgcolor: 'primary.light',
                                        color: 'primary.contrastText',
                                    }}
                                >
                                    {stat.icon}
                                </Box>

                                <Box>
                                    <Typography color="text.secondary">
                                        {stat.label}
                                    </Typography>
                                    <Typography variant="h4" sx={{ fontWeight: 700 }}>
                                        {stat.value}
                                    </Typography>
                                </Box>
                            </Stack>
                        </Paper>
                    </Grid>
                ))}
            </Grid>

            <Paper sx={{ p: 3, borderRadius: 2, mt: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 700, mb: 1 }}>
                    Next steps
                </Typography>
                <Typography color="text.secondary">
                    Replace mock data in the API layer with your Laravel endpoints,
                    then keep the page components unchanged.
                </Typography>
            </Paper>
        </>
    );
}
