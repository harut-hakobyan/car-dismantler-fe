import CrudPage from '../../components/CrudPage';
import { users } from '../../api/mockData';
import type { Column } from '../../components/CrudPage';
import type { UserResource } from '../../types/resources';

const columns: Column<UserResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'role', label: 'Role' },
    { key: 'status', label: 'Status', type: 'status' },
];

export default function UsersPage() {
    return (
        <CrudPage
            title="Users"
            description="Manage team members and account access."
            actionLabel="Add user"
            initialRows={users}
            columns={columns}
        />
    );
}
