import React from 'react';
import ReactDOM from 'react-dom/client';

import { QueryClient } from '@tanstack/react-query';

import { QueryClientProvider } from '@tanstack/react-query';

import { Toaster } from 'react-hot-toast';

import { AuthProvider } from './auth/AuthContext';

import AppRouter from './routes/AppRouter';

const queryClient = new QueryClient();

ReactDOM.createRoot(
    document.getElementById('root')!
).render(

    <React.StrictMode>

        <QueryClientProvider client={queryClient}>

            <AuthProvider>

                <AppRouter />

                <Toaster
                    position="top-right"
                />

            </AuthProvider>

        </QueryClientProvider>

    </React.StrictMode>

);