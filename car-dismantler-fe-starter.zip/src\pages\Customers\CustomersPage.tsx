import CrudPage, { type Column } from '../../components/CrudPage';
import { customers } from '../../api/mockData';
import type { CustomerResource } from '../../types/resources';

const columns: Column<CustomerResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'name', label: 'Customer' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    { key: 'orders', label: 'Orders', type: 'number' },
    { key: 'status', label: 'Status', type: 'status' },
];

export default function CustomersPage() {
    return (
        <CrudPage
            title="Customers"
            description="Maintain buyer profiles and order history."
            actionLabel="Add customer"
            initialRows={customers}
            columns={columns}
        />
    );
}
