import {
    FormControlLabel,
    Paper,
    Stack,
    Switch,
    TextField,
} from '@mui/material';
import PageHeader from '../../components/PageHeader';

export default function SettingsPage() {
    return (
        <>
            <PageHeader
                title="Settings"
                description="Configure core admin preferences."
            />

            <Paper sx={{ p: 3, borderRadius: 2, maxWidth: 720 }}>
                <Stack spacing={2}>
                    <TextField label="Company name" defaultValue="Car Dismantler" />
                    <TextField label="Default currency" defaultValue="USD" />
                    <FormControlLabel
                        control={<Switch defaultChecked />}
                        label="Enable low-stock alerts"
                    />
                    <FormControlLabel
                        control={<Switch defaultChecked />}
                        label="Require confirmation before deleting records"
                    />
                </Stack>
            </Paper>
        </>
    );
}
