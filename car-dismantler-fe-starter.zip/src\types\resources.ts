export type Status = 'Active' | 'Inactive' | 'Pending' | 'Completed' | 'Cancelled';

export interface UserResource {
    id: number;
    name: string;
    email: string;
    role: string;
    status: Status;
}

export interface RoleResource {
    id: number;
    name: string;
    permissions: string;
    users: number;
    status: Status;
}

export interface CarResource {
    id: number;
    vin: string;
    make: string;
    model: string;
    year: number;
    status: Status;
}

export interface PartResource {
    id: number;
    sku: string;
    name: string;
    car: string;
    price: number;
    stock: number;
    status: Status;
}

export interface OrderResource {
    id: number;
    number: string;
    customer: string;
    total: number;
    status: Status;
    createdAt: string;
}

export interface CustomerResource {
    id: number;
    name: string;
    email: string;
    phone: string;
    orders: number;
    status: Status;
}

export type ResourceRecord =
    | UserResource
    | RoleResource
    | CarResource
    | PartResource
    | OrderResource
    | CustomerResource;
