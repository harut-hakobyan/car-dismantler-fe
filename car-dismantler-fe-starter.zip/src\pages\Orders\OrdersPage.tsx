import CrudPage, { type Column } from '../../components/CrudPage';
import { orders } from '../../api/mockData';
import type { OrderResource } from '../../types/resources';

const columns: Column<OrderResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'number', label: 'Order' },
    { key: 'customer', label: 'Customer' },
    { key: 'total', label: 'Total', type: 'currency' },
    { key: 'status', label: 'Status', type: 'status' },
    { key: 'createdAt', label: 'Created', type: 'date' },
];

export default function OrdersPage() {
    return (
        <CrudPage
            title="Orders"
            description="Review customer orders and fulfillment state."
            actionLabel="Add order"
            initialRows={orders}
            columns={columns}
        />
    );
}
