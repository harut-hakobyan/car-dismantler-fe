import type {
    CarResource,
    CustomerResource,
    OrderResource,
    PartResource,
    RoleResource,
    UserResource,
} from '../types/resources';

export const users: UserResource[] = [
    { id: 1, name: 'Administrator', email: 'admin@example.com', role: 'Owner', status: 'Active' },
    { id: 2, name: 'Parts Manager', email: 'parts@example.com', role: 'Manager', status: 'Active' },
    { id: 3, name: 'Sales Operator', email: 'sales@example.com', role: 'Sales', status: 'Inactive' },
];

export const roles: RoleResource[] = [
    { id: 1, name: 'Owner', permissions: 'Full access', users: 1, status: 'Active' },
    { id: 2, name: 'Manager', permissions: 'Inventory, orders, customers', users: 4, status: 'Active' },
    { id: 3, name: 'Sales', permissions: 'Orders and customers', users: 6, status: 'Active' },
];

export const cars: CarResource[] = [
    { id: 1, vin: 'JTDBR32E720000001', make: 'Toyota', model: 'Corolla', year: 2018, status: 'Active' },
    { id: 2, vin: 'WBA3A5C50DF000002', make: 'BMW', model: '328i', year: 2016, status: 'Pending' },
    { id: 3, vin: 'WAUZZZ8K9AA000003', make: 'Audi', model: 'A4', year: 2017, status: 'Active' },
];

export const parts: PartResource[] = [
    { id: 1, sku: 'ENG-TOY-001', name: 'Engine assembly', car: 'Toyota Corolla 2018', price: 1450, stock: 1, status: 'Active' },
    { id: 2, sku: 'DR-BMW-014', name: 'Front right door', car: 'BMW 328i 2016', price: 420, stock: 2, status: 'Active' },
    { id: 3, sku: 'LGT-AUD-023', name: 'LED headlight', car: 'Audi A4 2017', price: 280, stock: 4, status: 'Active' },
];

export const orders: OrderResource[] = [
    { id: 1, number: 'ORD-1001', customer: 'AutoFix Garage', total: 1730, status: 'Pending', createdAt: '2026-07-08' },
    { id: 2, number: 'ORD-1002', customer: 'North Parts LLC', total: 420, status: 'Completed', createdAt: '2026-07-07' },
    { id: 3, number: 'ORD-1003', customer: 'City Motors', total: 280, status: 'Cancelled', createdAt: '2026-07-05' },
];

export const customers: CustomerResource[] = [
    { id: 1, name: 'AutoFix Garage', email: 'orders@autofix.test', phone: '+1 555 0110', orders: 12, status: 'Active' },
    { id: 2, name: 'North Parts LLC', email: 'buy@northparts.test', phone: '+1 555 0111', orders: 8, status: 'Active' },
    { id: 3, name: 'City Motors', email: 'parts@citymotors.test', phone: '+1 555 0112', orders: 3, status: 'Inactive' },
];
