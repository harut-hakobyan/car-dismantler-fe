import {
    BrowserRouter,
    Routes,
    Route,
} from 'react-router-dom';

import LoginPage from '../pages/Login';

import DashboardLayout from '../layouts/DashboardLayout';

import DashboardPage from '../pages/Dashboard/DashboardPage';

import ProtectedRoute from '../auth/ProtectedRoute';
import UsersPage from '../pages/Users/UsersPage';
import RolesPage from '../pages/Roles/RolesPage';
import CarsPage from '../pages/Cars/CarsPage';
import PartsPage from '../pages/Parts/PartsPage';
import OrdersPage from '../pages/Orders/OrdersPage';
import CustomersPage from '../pages/Customers/CustomersPage';
import ProfilePage from '../pages/Profile/ProfilePage';
import SettingsPage from '../pages/Settings/SettingsPage';

export default function AppRouter() {
    return (
        <BrowserRouter>

            <Routes>

                <Route
                    path="/login"
                    element={<LoginPage />}
                />

                <Route
                    path="/"
                    element={
                        <ProtectedRoute>
                            <DashboardLayout />
                        </ProtectedRoute>
                    }
                >
                    <Route
                        index
                        element={<DashboardPage />}
                    />

                    <Route
                        path="users"
                        element={<UsersPage />}
                    />

                    <Route
                        path="roles"
                        element={<RolesPage />}
                    />

                    <Route
                        path="cars"
                        element={<CarsPage />}
                    />

                    <Route
                        path="parts"
                        element={<PartsPage />}
                    />

                    <Route
                        path="orders"
                        element={<OrdersPage />}
                    />

                    <Route
                        path="customers"
                        element={<CustomersPage />}
                    />

                    <Route
                        path="profile"
                        element={<ProfilePage />}
                    />

                    <Route
                        path="settings"
                        element={<SettingsPage />}
                    />
                </Route>

            </Routes>

        </BrowserRouter>
    );
}
