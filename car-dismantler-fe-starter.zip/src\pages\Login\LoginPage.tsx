import {
    Box,
} from '@mui/material';

import LoginForm from './LoginForm';

export default function LoginPage() {
    return (
        <Box
            sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                minHeight: '100vh',
                bgcolor: '#f3f6f8',
                p: 2,
            }}
        >
            <LoginForm />
        </Box>
    );
}
