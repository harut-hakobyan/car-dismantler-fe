import CrudPage, { type Column } from '../../components/CrudPage';
import { parts } from '../../api/mockData';
import type { PartResource } from '../../types/resources';

const columns: Column<PartResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'sku', label: 'SKU' },
    { key: 'name', label: 'Part' },
    { key: 'car', label: 'Source car' },
    { key: 'price', label: 'Price', type: 'currency' },
    { key: 'stock', label: 'Stock', type: 'number' },
    { key: 'status', label: 'Status', type: 'status' },
];

export default function PartsPage() {
    return (
        <CrudPage
            title="Parts"
            description="Manage sellable inventory, stock, and pricing."
            actionLabel="Add part"
            initialRows={parts}
            columns={columns}
        />
    );
}
