import CrudPage, { type Column } from '../../components/CrudPage';
import { cars } from '../../api/mockData';
import type { CarResource } from '../../types/resources';

const columns: Column<CarResource>[] = [
    { key: 'id', label: 'ID', type: 'number' },
    { key: 'vin', label: 'VIN' },
    { key: 'make', label: 'Make' },
    { key: 'model', label: 'Model' },
    { key: 'year', label: 'Year', type: 'number' },
    { key: 'status', label: 'Status', type: 'status' },
];

export default function CarsPage() {
    return (
        <CrudPage
            title="Cars"
            description="Track incoming vehicles and dismantling status."
            actionLabel="Add car"
            initialRows={cars}
            columns={columns}
        />
    );
}
