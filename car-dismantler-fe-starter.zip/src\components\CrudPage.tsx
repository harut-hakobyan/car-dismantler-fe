import { useMemo, useState } from 'react';
import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    MenuItem,
    Paper,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    Tooltip,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import toast from 'react-hot-toast';
import PageHeader from './PageHeader';
import StatusChip from './StatusChip';
import type { ResourceRecord, Status } from '../types/resources';

export interface Column<T> {
    key: keyof T;
    label: string;
    type?: 'text' | 'number' | 'currency' | 'date' | 'status';
}

interface CrudPageProps<T extends ResourceRecord> {
    title: string;
    description: string;
    actionLabel: string;
    initialRows: T[];
    columns: Column<T>[];
}

const statuses: Status[] = ['Active', 'Inactive', 'Pending', 'Completed', 'Cancelled'];

function createEmptyRow<T extends ResourceRecord>(columns: Column<T>[], nextId: number): T {
    const row: Record<string, string | number> = { id: nextId };

    columns.forEach((column) => {
        if (column.key === 'id') {
            return;
        }

        if (column.type === 'number' || column.type === 'currency') {
            row[String(column.key)] = 0;
            return;
        }

        if (column.type === 'status') {
            row[String(column.key)] = 'Active';
            return;
        }

        row[String(column.key)] = '';
    });

    return row as unknown as T;
}

function formatValue<T extends ResourceRecord>(row: T, column: Column<T>) {
    const value = row[column.key];

    if (column.type === 'currency' && typeof value === 'number') {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            maximumFractionDigits: 0,
        }).format(value);
    }

    if (column.type === 'status') {
        return <StatusChip status={value as Status} />;
    }

    return String(value);
}

export default function CrudPage<T extends ResourceRecord>({
    title,
    description,
    actionLabel,
    initialRows,
    columns,
}: CrudPageProps<T>) {
    const [rows, setRows] = useState<T[]>(initialRows);
    const [query, setQuery] = useState('');
    const [editingRow, setEditingRow] = useState<T | null>(null);
    const [deleteRow, setDeleteRow] = useState<T | null>(null);

    const filteredRows = useMemo(() => {
        const normalizedQuery = query.trim().toLowerCase();

        if (!normalizedQuery) {
            return rows;
        }

        return rows.filter((row) =>
            Object.values(row).some((value) =>
                String(value).toLowerCase().includes(normalizedQuery)
            )
        );
    }, [query, rows]);

    function openCreateDialog() {
        const nextId = Math.max(0, ...rows.map((row) => row.id)) + 1;
        setEditingRow(createEmptyRow(columns, nextId));
    }

    function saveRow() {
        if (!editingRow) {
            return;
        }

        setRows((currentRows) => {
            const exists = currentRows.some((row) => row.id === editingRow.id);

            if (exists) {
                return currentRows.map((row) =>
                    row.id === editingRow.id ? editingRow : row
                );
            }

            return [editingRow, ...currentRows];
        });

        toast.success('Saved');
        setEditingRow(null);
    }

    function confirmDelete() {
        if (!deleteRow) {
            return;
        }

        setRows((currentRows) =>
            currentRows.filter((row) => row.id !== deleteRow.id)
        );
        toast.success('Deleted');
        setDeleteRow(null);
    }

    function updateEditingField(column: Column<T>, value: string) {
        if (!editingRow) {
            return;
        }

        setEditingRow({
            ...editingRow,
            [column.key]:
                column.type === 'number' || column.type === 'currency'
                    ? Number(value)
                    : value,
        });
    }

    return (
        <>
            <PageHeader
                title={title}
                description={description}
                actionLabel={actionLabel}
                onAction={openCreateDialog}
            />

            <Paper sx={{ p: 2, borderRadius: 2 }}>
                <Stack
                    direction={{ xs: 'column', md: 'row' }}
                    spacing={2}
                    sx={{
                        justifyContent: 'space-between',
                        alignItems: { xs: 'stretch', md: 'center' },
                        mb: 2,
                    }}
                >
                    <TextField
                        size="small"
                        placeholder="Search"
                        value={query}
                        onChange={(event) => setQuery(event.target.value)}
                    />
                </Stack>

                <TableContainer>
                    <Table size="small">
                        <TableHead>
                            <TableRow>
                                {columns.map((column) => (
                                    <TableCell key={String(column.key)}>
                                        {column.label}
                                    </TableCell>
                                ))}
                                <TableCell align="right">Actions</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {filteredRows.map((row) => (
                                <TableRow key={row.id} hover>
                                    {columns.map((column) => (
                                        <TableCell key={String(column.key)}>
                                            {formatValue(row, column)}
                                        </TableCell>
                                    ))}
                                    <TableCell align="right">
                                        <Tooltip title="Edit">
                                            <IconButton
                                                size="small"
                                                onClick={() => setEditingRow(row)}
                                            >
                                                <EditIcon fontSize="small" />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Delete">
                                            <IconButton
                                                size="small"
                                                color="error"
                                                onClick={() => setDeleteRow(row)}
                                            >
                                                <DeleteIcon fontSize="small" />
                                            </IconButton>
                                        </Tooltip>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>

            <Dialog
                open={!!editingRow}
                onClose={() => setEditingRow(null)}
                fullWidth
                maxWidth="sm"
            >
                <DialogTitle>
                    {editingRow && rows.some((row) => row.id === editingRow.id)
                        ? `Edit ${title}`
                        : `Create ${title}`}
                </DialogTitle>

                <DialogContent>
                    <Stack spacing={2} sx={{ mt: 1 }}>
                        {editingRow &&
                            columns
                                .filter((column) => column.key !== 'id')
                                .map((column) => {
                                    const value = editingRow[column.key];

                                    if (column.type === 'status') {
                                        return (
                                            <TextField
                                                key={String(column.key)}
                                                select
                                                label={column.label}
                                                value={String(value)}
                                                onChange={(event) =>
                                                    updateEditingField(column, event.target.value)
                                                }
                                            >
                                                {statuses.map((status) => (
                                                    <MenuItem key={status} value={status}>
                                                        {status}
                                                    </MenuItem>
                                                ))}
                                            </TextField>
                                        );
                                    }

                                    return (
                                        <TextField
                                            key={String(column.key)}
                                            label={column.label}
                                            type={
                                                column.type === 'number' ||
                                                column.type === 'currency'
                                                    ? 'number'
                                                    : 'text'
                                            }
                                            value={String(value)}
                                            onChange={(event) =>
                                                updateEditingField(column, event.target.value)
                                            }
                                        />
                                    );
                                })}
                    </Stack>
                </DialogContent>

                <DialogActions>
                    <Button onClick={() => setEditingRow(null)}>Cancel</Button>
                    <Button variant="contained" onClick={saveRow}>
                        Save
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog open={!!deleteRow} onClose={() => setDeleteRow(null)}>
                <DialogTitle>Delete record?</DialogTitle>
                <DialogContent>
                    <Box color="text.secondary">
                        This removes the selected record from the current table.
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDeleteRow(null)}>Cancel</Button>
                    <Button color="error" variant="contained" onClick={confirmDelete}>
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
}
