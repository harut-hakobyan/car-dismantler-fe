import {
    AppBar,
    Avatar,
    Box,
    Divider,
    Drawer,
    IconButton,
    List,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import GroupIcon from '@mui/icons-material/Group';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import LogoutIcon from '@mui/icons-material/Logout';
import MenuIcon from '@mui/icons-material/Menu';
import PeopleIcon from '@mui/icons-material/People';
import SecurityIcon from '@mui/icons-material/Security';
import SettingsIcon from '@mui/icons-material/Settings';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';

const drawerWidth = 264;

const navItems = [
    { label: 'Dashboard', path: '/', icon: <DashboardIcon /> },
    { label: 'Users', path: '/users', icon: <GroupIcon /> },
    { label: 'Roles', path: '/roles', icon: <SecurityIcon /> },
    { label: 'Cars', path: '/cars', icon: <DirectionsCarIcon /> },
    { label: 'Parts', path: '/parts', icon: <Inventory2Icon /> },
    { label: 'Orders', path: '/orders', icon: <ShoppingCartIcon /> },
    { label: 'Customers', path: '/customers', icon: <PeopleIcon /> },
    { label: 'Settings', path: '/settings', icon: <SettingsIcon /> },
];

export default function DashboardLayout() {
    const { logout, user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [mobileOpen, setMobileOpen] = useState(false);

    async function handleLogout() {
        await logout();
        navigate('/login', { replace: true });
    }

    const drawer = (
        <Box
            sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
            }}
        >
            <Toolbar>
                <Typography variant="h6" sx={{ fontWeight: 800 }}>
                    Car Dismantler
                </Typography>
            </Toolbar>

            <Divider />

            <List sx={{ px: 1, py: 2, flexGrow: 1 }}>
                {navItems.map((item) => {
                    const selected =
                        item.path === '/'
                            ? location.pathname === '/'
                            : location.pathname.startsWith(item.path);

                    return (
                        <ListItemButton
                            key={item.path}
                            selected={selected}
                            onClick={() => {
                                navigate(item.path);
                                setMobileOpen(false);
                            }}
                            sx={{ borderRadius: 1.5, mb: 0.5 }}
                        >
                            <ListItemIcon>{item.icon}</ListItemIcon>
                            <ListItemText primary={item.label} />
                        </ListItemButton>
                    );
                })}
            </List>

            <Divider />

            <List sx={{ px: 1, py: 2 }}>
                <ListItemButton
                    onClick={() => {
                        navigate('/profile');
                        setMobileOpen(false);
                    }}
                    sx={{ borderRadius: 1.5, mb: 0.5 }}
                >
                    <ListItemIcon>
                        <Avatar sx={{ width: 28, height: 28 }}>
                            {user?.name?.charAt(0) ?? 'A'}
                        </Avatar>
                    </ListItemIcon>
                    <ListItemText
                        primary={user?.name ?? 'Administrator'}
                        secondary={user?.email ?? 'admin@example.com'}
                    />
                </ListItemButton>

                <ListItemButton onClick={handleLogout} sx={{ borderRadius: 1.5 }}>
                    <ListItemIcon>
                        <LogoutIcon />
                    </ListItemIcon>
                    <ListItemText primary="Logout" />
                </ListItemButton>
            </List>
        </Box>
    );

    return (
        <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: '#f3f6f8' }}>
            <AppBar
                position="fixed"
                elevation={0}
                sx={{
                    width: { md: `calc(100% - ${drawerWidth}px)` },
                    ml: { md: `${drawerWidth}px` },
                    bgcolor: 'background.paper',
                    color: 'text.primary',
                    borderBottom: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Toolbar>
                    <IconButton
                        edge="start"
                        onClick={() => setMobileOpen(true)}
                        sx={{ mr: 2, display: { md: 'none' } }}
                    >
                        <MenuIcon />
                    </IconButton>

                    <Typography sx={{ flexGrow: 1, fontWeight: 700 }}>
                        Admin Panel
                    </Typography>

                    <IconButton onClick={() => navigate('/profile')}>
                        <Avatar sx={{ width: 32, height: 32 }}>
                            {user?.name?.charAt(0) ?? 'A'}
                        </Avatar>
                    </IconButton>
                </Toolbar>
            </AppBar>

            <Box component="nav" sx={{ width: { md: drawerWidth }, flexShrink: { md: 0 } }}>
                <Drawer
                    variant="temporary"
                    open={mobileOpen}
                    onClose={() => setMobileOpen(false)}
                    ModalProps={{ keepMounted: true }}
                    sx={{
                        display: { xs: 'block', md: 'none' },
                        '& .MuiDrawer-paper': { width: drawerWidth },
                    }}
                >
                    {drawer}
                </Drawer>

                <Drawer
                    variant="permanent"
                    sx={{
                        display: { xs: 'none', md: 'block' },
                        '& .MuiDrawer-paper': {
                            width: drawerWidth,
                            boxSizing: 'border-box',
                        },
                    }}
                    open
                >
                    {drawer}
                </Drawer>
            </Box>

            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    width: { md: `calc(100% - ${drawerWidth}px)` },
                    p: { xs: 2, md: 3 },
                    mt: 8,
                }}
            >
                <Outlet />
            </Box>
        </Box>
    );
}
