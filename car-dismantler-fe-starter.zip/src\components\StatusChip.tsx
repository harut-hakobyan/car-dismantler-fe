import { Chip } from '@mui/material';
import type { Status } from '../types/resources';

const colorByStatus: Record<Status, 'success' | 'default' | 'warning' | 'info' | 'error'> = {
    Active: 'success',
    Inactive: 'default',
    Pending: 'warning',
    Completed: 'info',
    Cancelled: 'error',
};

export default function StatusChip({ status }: { status: Status }) {
    return (
        <Chip
            label={status}
            color={colorByStatus[status]}
            size="small"
            variant="outlined"
        />
    );
}
