import type {LoginRequest, LoginResponse} from '../auth/types';

/*
|--------------------------------------------------------------------------
| Mock API
|--------------------------------------------------------------------------
|
| Replace these functions with Laravel endpoints later.
|
*/

export async function login(
    data: LoginRequest
): Promise<LoginResponse> {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (
                data.email === 'admin@example.com' &&
                data.password === 'password'
            ) {
                resolve({
                    token: 'mock-token-123456789',
                    user: {
                        id: 1,
                        name: 'Administrator',
                        email: 'admin@example.com',
                    },
                });

                return;
            }

            reject(new Error('Invalid email or password'));
        }, 700);
    });

    /*
    TODO

    const response = await api.post('/login', data);

    return {
        token: response.data.token,
        user: response.data.user,
    };
    */
}

export async function logout() {
    /*
    TODO

    await api.post('/logout');
    */

    return Promise.resolve();
}

export async function me() {
    /*
    TODO

    return api.get('/me');
    */

    return Promise.resolve({
        id: 1,
        name: 'Administrator',
        email: 'admin@example.com',
    });
}